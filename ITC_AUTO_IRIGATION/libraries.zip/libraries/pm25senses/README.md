# pm25senses
![alt_text](https://img.shields.io/badge/Compatible-ArduinoIDE-green.svg "bulidpassing")
![alt_text](https://img.shields.io/badge/Support-ESP8266-blue.svg "bulidpassing")<br>
This lib use for send a PM2.5 dust quality to PM25 platform by Senses<br>
visit website at : http://pm25senses.iottweet.com
