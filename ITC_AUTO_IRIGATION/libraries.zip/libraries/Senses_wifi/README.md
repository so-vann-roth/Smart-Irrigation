# Senses_wifi
A library use for send data from IoT device to "SENSES" IoT platfrom.<br>
visit us at : https://www.sensesiot.com
